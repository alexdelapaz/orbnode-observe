#!/usr/bin/env python3
"""Hermes + Phoenix + NVIDIA NIM live observability dashboard."""
import argparse
import json
import math
import os
import re
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urljoin

import httpx
import pandas as pd
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from phoenix.client import Client
import uvicorn

app = FastAPI(title="Hermes Live Observatory")
PHOENIX = os.getenv('PHOENIX_ENDPOINT', 'http://phoenix:6006')
PROJECT = os.getenv('PHOENIX_PROJECT', 'hermes')
NIM = os.getenv('NIM_ENDPOINT', '')
WINDOW_MIN = int(os.getenv('PHOENIX_WINDOW_MIN', '60'))
LIMIT = int(os.getenv('PHOENIX_SPAN_LIMIT', '3000'))
_phoenix = Client(base_url=PHOENIX)
_lock = threading.Lock()
_cached = {'ts': 0.0, 'data': None}
_last_metric = {'ts': None, 'generation': None, 'prompt': None}


def clean(v):
    if isinstance(v, dict): return {str(k):clean(x) for k,x in v.items()}
    if isinstance(v, (list,tuple)): return [clean(x) for x in v]
    if v is None: return None
    if isinstance(v, (pd.Timestamp,datetime)): return v.isoformat() if not pd.isna(v) else None
    if isinstance(v, (int,float)):
        return v if math.isfinite(v) else None
    try:
        if pd.isna(v): return None
    except (TypeError, ValueError): pass
    return str(v) if not isinstance(v,(str,bool)) else v


def value(row, *keys, default=None):
    for k in keys:
        if k in row:
            v = row[k]
            if v is None: continue
            try:
                if pd.isna(v): continue
            except (TypeError,ValueError): pass
            if v != '': return v
    return default


def dt(v):
    if v is None: return None
    t = pd.to_datetime(v, utc=True, errors='coerce')
    return None if pd.isna(t) else t.to_pydatetime()


def tofloat(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError,ValueError): return None


def fetch_spans():
    df = _phoenix.spans.get_spans_dataframe(
        project_identifier=PROJECT,
        start_time=datetime.now(timezone.utc)-timedelta(minutes=WINDOW_MIN),
        limit=LIMIT,
    )
    if df.index.name and df.index.name in df.columns:
        df = df.reset_index(drop=True)
    else:
        df = df.reset_index()
    rows = df.to_dict('records')
    result = []
    for r in rows:
        start = dt(value(r,'start_time'))
        end = dt(value(r,'end_time'))
        duration = (end-start).total_seconds() if start and end else None
        kind = str(value(r,'span_kind','attributes.openinference.span.kind',default='UNKNOWN')).upper()
        status = str(value(r,'status_code',default='UNSET')).upper()
        name = str(value(r,'name',default='unnamed'))
        model = value(r,'attributes.llm.model_name','llm.model_name')
        tool = value(r,'attributes.tool.name','tool.name',default=name if kind=='TOOL' else None)
        error = value(r,'status_message','status_description','attributes.error.message', 'attributes.exception.message','attributes.exception.type')
        output_tokens = tofloat(value(r,'attributes.llm.token_count.completion','attributes.llm.token_count.output','attributes.gen_ai.usage.output_tokens','attributes.llm.usage.output_tokens','llm.token_count.completion'))
        input_tokens = tofloat(value(r,'attributes.llm.token_count.prompt','attributes.llm.token_count.input','attributes.gen_ai.usage.input_tokens','attributes.llm.usage.input_tokens','llm.token_count.prompt'))
        agent = value(r,'attributes.service.instance.id','attributes.agent.id','attributes.agent.name','attributes.service.name','attributes.resource.service.name','service.name',default='unattributed')
        result.append({'id':str(value(r,'context.span_id','span_id',default='')),
                       'trace':str(value(r,'context.trace_id','trace_id',default='')),
                       'parent':str(value(r,'parent_id','parent_span_id',default='')),
                       'name':name,'kind':kind,'status':status,'error':str(error or ''),
                       'model':str(model or ''),'tool':str(tool or ''),'agent':str(agent),
                       'start':start.isoformat() if start else None,
                       'end':end.isoformat() if end else None,'duration':duration,
                       'output_tokens':output_tokens,'input_tokens':input_tokens})
    result.sort(key=lambda r:r['start'] or '', reverse=True)
    return result


def summarize(rows):
    kinds = {}
    for r in rows: kinds[r['kind']] = kinds.get(r['kind'],0)+1
    tools = {}
    for r in rows:
        if r['kind']=='TOOL':
            n=r['tool'] or r['name']
            e=tools.setdefault(n,{'name':n,'calls':0,'errors':0,'avg_s':0.0,'durations':[]})
            e['calls']+=1
            e['errors']+=r['status']=='ERROR'
            if r['duration'] is not None: e['durations'].append(r['duration'])
    for t in tools.values():
        t['avg_s'] = round(sum(t['durations'])/len(t['durations']),3) if t['durations'] else None
        del t['durations']
    traces={}
    for r in rows:
        if not r['trace']: continue
        item=traces.setdefault(r['trace'],{'id':r['trace'],'spans':0,'errors':0,'llm':0,'tools':0,'first':r['start'],'last':r['end']})
        item['spans']+=1
        item['errors']+=r['status']=='ERROR'
        item['llm']+=r['kind']=='LLM'
        item['tools']+=r['kind']=='TOOL'
        if r['start'] and (not item['first'] or r['start'] < item['first']):item['first']=r['start']
        if r['end'] and (not item['last'] or r['end'] > item['last']):item['last']=r['end']
    errors=[r for r in rows if r['status']=='ERROR']
    llms=[r for r in rows if r['kind']=='LLM']
    return clean({'updated':datetime.now(timezone.utc).isoformat(), 'project':PROJECT, 'window_min':WINDOW_MIN,
           'summary':{'spans':len(rows),'traces':len(traces),'llm_calls':len(llms),'tool_calls':kinds.get('TOOL',0),
                      'error_spans':len(errors),'traces_with_errors':sum(t['errors']>0 for t in traces.values()),
                      'output_tokens':sum(r['output_tokens'] or 0 for r in llms),
                      'input_tokens':sum(r['input_tokens'] or 0 for r in llms),
                      'tokenized_llm_calls':sum(r['output_tokens'] is not None for r in llms)},
           'kinds':[{'kind':k,'count':v} for k,v in sorted(kinds.items(),key=lambda a:-a[1])],
           'tools':sorted(tools.values(),key=lambda t:-t['calls'])[:25],
           'errors':errors[:30],
           'recent_spans':rows[:90],
           'recent_traces':sorted(traces.values(),key=lambda t:t['first'] or '',reverse=True)[:15]})


@app.get('/api/spans')
def spans_api():
    with _lock:
        if _cached['data'] is not None and time.monotonic()-_cached['ts']<5:
            return _cached['data']
    # Do not hide Phoenix failures as a false zero count.
    result=summarize(fetch_spans())
    with _lock:
        _cached.update(ts=time.monotonic(),data=result)
    return result


METRIC_RE=re.compile(r'^([^\s{]+)(?:\{[^}]*\})?\s+([-+\deE.]+)(?:\s|$)')

def scrape_nim():
    if not NIM:
        return {'enabled':False,'note':'Set NIM_ENDPOINT to enable live server token throughput'}
    errors=[]
    body=None
    endpoint=None
    for suffix in ('/v1/metrics','/metrics'):
        u=NIM.rstrip('/')+suffix
        try:
            resp=httpx.get(u,timeout=3.0)
            resp.raise_for_status()
            if 'generation_tokens_total' in resp.text or 'prompt_tokens_total' in resp.text:
                body=resp.text;endpoint=u;break
            errors.append(f'{u}: no expected token counters')
        except Exception as ex: errors.append(f'{u}: {ex}')
    if body is None:
        return {'enabled':True,'error':'; '.join(errors), 'note':'Check NIM metrics endpoint access and names'}
    metrics={}
    for line in body.splitlines():
        if line.startswith('#'):continue
        match=METRIC_RE.match(line)
        if not match:continue
        key=match.group(1)
        v=tofloat(match.group(2))
        if v is None:continue
        metrics[key]=metrics.get(key,0.0)+v
    def metric(name):
        vals=[v for k,v in metrics.items() if k.rsplit(':',1)[-1]==name]
        return sum(vals) if vals else None
    generation=metric('generation_tokens_total')
    prompt=metric('prompt_tokens_total')
    running=metric('num_requests_running')
    waiting=metric('num_requests_waiting')
    cache=metric('kv_cache_usage_perc')
    now=time.monotonic()
    with _lock:
        prev=_last_metric.copy()
        _last_metric.update(ts=now,generation=generation,prompt=prompt)
    elapsed=(now-prev['ts']) if prev['ts'] is not None else None
    def rate(cur,old):
        return round((cur-old)/elapsed,2) if elapsed and elapsed>0 and cur is not None and old is not None and cur>=old else None
    return clean({'enabled':True,'endpoint':endpoint,'generated_tps':rate(generation,prev['generation']),
                  'prompt_tps':rate(prompt,prev['prompt']), 'generation_total':generation,
                  'prompt_total':prompt,'running':running,'waiting':waiting,'kv_cache_fraction':cache,
                  'note':'Aggregate NIM token/sec across all clients; not per-Hermes decode speed'})


@app.get('/api/live')
def live_api():
    return scrape_nim()


@app.get('/')
def index():
    return HTMLResponse(Path(__file__).with_name('dashboard.html').read_text(encoding='utf-8'))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--project',default=PROJECT)
    parser.add_argument('--nim',default=NIM)
    parser.add_argument('--port',type=int,default=8090)
    args=parser.parse_args()
    PROJECT=args.project;NIM=args.nim
    print(f'Phoenix: {PHOENIX}, project: {PROJECT}, NIM: {NIM or "disabled"}')
    uvicorn.run(app,host='0.0.0.0',port=args.port)
