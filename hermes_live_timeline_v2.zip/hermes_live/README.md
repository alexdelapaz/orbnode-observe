# Hermes Live Observatory

Standalone FastAPI + HTML dashboard for multiple Hermes agents using one Phoenix project and an NVIDIA NIM server.

## Run in a Python Docker container

Copy both files into `/work` in your existing container, then:

```bash
python -m pip install -U arize-phoenix-client fastapi uvicorn httpx pandas
export PHOENIX_ENDPOINT=http://phoenix:6006
export PHOENIX_PROJECT=YOUR_ACTUAL_PROJECT_NAME
# Set this to your NIM IP/host, reachable FROM the Python container:
export NIM_ENDPOINT=http://spark-4313:8000
python live_monitor.py --port 8090
```

Open `http://localhost:8090` with a published/forwarded Docker port 8090. Check `http://localhost:8090/api/live` and `/api/spans` individually.

## Notes

- NIM throughput uses differences of cumulative generation/prompt-token counters over successful requests to `/v1/metrics` (fallback `/metrics`). First sample intentionally shows no rate.
- If a metrics endpoint returns no data, the dashboard shows an error instead of inventing numbers. Current NIM metrics may require network, authentication, or an enabled exporter.
- Token throughput is **aggregate across all traffic on that NIM**. You cannot assign it to a particular Hermes agent without request-level instrumentation or separate NIM instances.
- Phoenix spans are normally exported when they finish, so active tool/LLM stages may be delayed until completion; the NIM running-request count updates independently.
- Traces containing an ERROR are not automatically failed tasks. Evaluations/annotations are necessary for actual task success.
- The trace timeline uses up to 90 recent spans for performance; select a narrower time window for more complete trace views.
- Limit and window: `PHOENIX_SPAN_LIMIT=3000`, `PHOENIX_WINDOW_MIN=60`.
- Refresh intervals: NIM 2 seconds, Phoenix 5 seconds; change in `dashboard.html`.
- Multiple Hermes agents sharing one NIM: aggregate NIM throughput is across all traffic; tag spans with `service.instance.id` or an `agent.id` to compare agents.

## Timeline v2 update (only Recent Trace Timelines)

The Recent Trace Timelines now retain the colored completed LLM, TOOL, and error
segments while the full trace duration grows. Gray context/parent spans are drawn
behind those calls instead of covering them. The backend returns all available
spans for the eight displayed traces in `timeline_spans`; the separate recent
actions table still uses the 90 latest spans. Browser history persists while a
trace remains displayed. Refresh the page after replacing both files.

Trace history is limited to the configured Phoenix lookback window
(`PHOENIX_WINDOW_MIN`, default 60) and the span fetch limit
(`PHOENIX_SPAN_LIMIT`, default 3000). To retain full long runs across page reloads,
increase those limits or add persistent per-trace storage.
