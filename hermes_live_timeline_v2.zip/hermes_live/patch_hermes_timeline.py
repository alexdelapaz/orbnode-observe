#!/usr/bin/env python3
"""Safely patch only Recent Trace Timelines in an existing Hermes Observatory.
Usage: python patch_hermes_timeline.py /work/hermes_live
Backs up dashboard.html and live_monitor.py as *.bak before modification.
"""
from pathlib import Path
import argparse
import ast

ORIGINAL_TIMELINE_CSS = '.lane{display:flex;align-items:center;gap:3px;min-height:18px}.block{height:12px;border-radius:3px;min-width:3px;cursor:help}'
UPDATED_TIMELINE_CSS = '.lane{position:relative;width:100%;height:22px;overflow:hidden;border:1px solid #293a50;border-radius:5px;background:#0a1320}.block{position:absolute;border-radius:2px;min-width:2px;cursor:help}.timeline-times{display:flex;justify-content:space-between;gap:10px;margin-top:3px;font-size:10px;color:var(--muted)}'
UPDATED_TIMELINE_JS = '// Keep completed spans for every displayed trace, even after they are no longer\n// in the server\'s short "recent actions" list. Timeline cache is bounded to the\n// eight currently displayed traces and reset when those traces leave the view.\nconst timelineHistory = new Map();\nconst timelineDate = value => {\n  const n = value ? Date.parse(value) : NaN;\n  return Number.isFinite(n) ? n : null;\n};\nfunction renderTimeline(data){\n  const root = $(\'timeline\');\n  root.replaceChildren();\n  const visible = (data.recent_traces || []).slice(0,8);\n  const visibleIds = new Set(visible.map(t => t.id));\n\n  // A new backend returns ALL spans belonging to the displayed traces.\n  // Fall back to recent_spans if the old backend is still in use.\n  for (const span of (data.timeline_spans || data.recent_spans || [])) {\n    if (!visibleIds.has(span.trace) || timelineDate(span.start) === null) continue;\n    if (!timelineHistory.has(span.trace)) timelineHistory.set(span.trace, new Map());\n    const items = timelineHistory.get(span.trace);\n    const key = span.id || `${span.start}|${span.name}|${span.kind}`;\n    const prior = items.get(key);\n    items.set(key, prior ? {\n      ...prior, ...span,\n      kind: span.kind && span.kind !== \'UNKNOWN\' ? span.kind : prior.kind,\n      status: span.status && span.status !== \'UNSET\' ? span.status : prior.status\n    } : span);\n  }\n  for (const traceId of timelineHistory.keys()) {\n    if (!visibleIds.has(traceId)) timelineHistory.delete(traceId);\n  }\n\n  for (const trace of visible) {\n    const parent = el(\'div\',undefined,\'trace\');\n    const head = el(\'div\',undefined,\'trace-head\');\n    head.append(\n      el(\'code\',trace.id.slice(0,20)+\'…\'),\n      el(\'span\',`${trace.spans} spans · ${trace.llm} LLM · ${trace.tools} tools · ${trace.errors} errors`,trace.errors?\'red\':\'muted\')\n    );\n    parent.append(head);\n    const items = [...(timelineHistory.get(trace.id)?.values() || [])]\n      .filter(s => timelineDate(s.start) !== null);\n    if (!items.length) {\n      parent.append(el(\'div\',\'No span details available for this trace\',\'note\'));\n      root.append(parent);\n      continue;\n    }\n\n    // Anchor the scale to the entire trace, not individual call durations.\n    // As a trace lengthens, every prior segment remains but shrinks to fit.\n    const starts = items.map(s => timelineDate(s.start));\n    const ends = items.map(s => timelineDate(s.end) ?? timelineDate(s.start));\n    const traceStart = timelineDate(trace.first);\n    const traceEnd = timelineDate(trace.last);\n    const min = Math.min(...starts, ...(traceStart === null ? [] : [traceStart]));\n    const max = Math.max(min+1, ...ends, ...(traceEnd === null ? [] : [traceEnd]));\n    const total = max-min;\n    const lane = el(\'div\',undefined,\'lane\');\n    lane.setAttribute(\'aria-label\',\'Timeline of completed spans within trace\');\n\n    function category(span) {\n      if (span.status === \'ERROR\') return \'error\';\n      if (span.kind === \'LLM\') return \'llm\';\n      if (span.kind === \'TOOL\') return \'tool\';\n      return \'other\';\n    }\n    const layer = {other:0,llm:1,tool:1,error:2};\n    // A long-lived gray root span should never paint over blue LLM / green TOOL.\n    // Render gray context first, colored calls next, error markers last.\n    items.sort((a,b) => (layer[category(a)]-layer[category(b)]) ||\n      (timelineDate(a.start)-timelineDate(b.start)));\n    for (const span of items) {\n      const from = timelineDate(span.start);\n      const to = Math.max(from, timelineDate(span.end) ?? from);\n      const left = Math.max(0,Math.min(100,(from-min)/total*100));\n      const width = Math.max(0,Math.min(100-left,(to-from)/total*100));\n      const type = category(span);\n      const block = el(\'div\',undefined,`block ${type}`);\n      block.style.left = `${left}%`;\n      block.style.width = `${width}%`;\n      block.style.zIndex = String(layer[type]+1);\n      block.style.top = type===\'other\' ? \'13px\' : \'3px\';\n      block.style.height = type===\'other\' ? \'5px\' : \'14px\';\n      block.style.opacity = type===\'other\' ? \'0.8\' : \'1\';\n      block.title = `${span.kind}: ${actionLabel(span)}\\n${fmt(span.duration)}s · ${span.status}\\n${span.start || \'\'}`;\n      lane.append(block);\n    }\n    parent.append(lane);\n    const times = el(\'div\',undefined,\'timeline-times\');\n    times.append(el(\'span\',new Date(min).toLocaleTimeString()),\n                 el(\'span\',`${fmt(total/1000)}s elapsed · ${items.length} recorded spans`),\n                 el(\'span\',new Date(max).toLocaleTimeString()));\n    parent.append(times);\n    root.append(parent);\n  }\n  if (!visible.length) root.append(el(\'p\',\'No traces in this time window\',\'muted\'));\n}\n'


def patch_html(s):
    if 'const timelineHistory = new Map();' not in s:
        start=s.find('function renderTimeline(data){')
        end=s.find('async function spans(){',start)
        if start<0 or end<0:
            raise RuntimeError('Cannot locate timeline renderer; no changes saved')
        s=s[:start]+UPDATED_TIMELINE_JS+s[end:]
    if ORIGINAL_TIMELINE_CSS in s:
        s=s.replace(ORIGINAL_TIMELINE_CSS,UPDATED_TIMELINE_CSS,1)
    elif UPDATED_TIMELINE_CSS not in s:
        raise RuntimeError('Cannot locate timeline CSS; no changes saved')
    return s


def patch_backend(s):
    if "'timeline_spans':timeline_spans" in s:
        return s
    needle="    return clean({'updated':datetime.now(timezone.utc).isoformat(), 'project':PROJECT, 'window_min':WINDOW_MIN,"
    addition="""    # Timeline-only data: retain every available span for the eight displayed traces.
    timeline_traces=sorted(traces.values(),key=lambda t:t['last'] or t['first'] or '',reverse=True)[:15]
    timeline_ids={t['id'] for t in timeline_traces[:8]}
    timeline_spans=[r for r in rows if r['trace'] in timeline_ids]
"""
    if s.count(needle)!=1:
        raise RuntimeError('Cannot locate summarize return; no changes saved')
    s=s.replace(needle,addition+needle,1)
    target="'recent_traces':sorted(traces.values(),key=lambda t:t['first'] or '',reverse=True)[:15]})"
    if s.count(target)!=1:
        raise RuntimeError('Cannot locate recent_traces field; no changes saved')
    s=s.replace(target,"'recent_traces':timeline_traces,\n           'timeline_spans':timeline_spans})",1)
    ast.parse(s)
    return s


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('directory',nargs='?',default='.',help='folder containing dashboard.html and live_monitor.py')
    args=parser.parse_args()
    directory=Path(args.directory).expanduser().resolve()
    html=directory/'dashboard.html'
    python=directory/'live_monitor.py'
    original_h=html.read_text(encoding='utf-8')
    original_p=python.read_text(encoding='utf-8')
    changed_h=patch_html(original_h)
    changed_p=patch_backend(original_p)
    for path, original, replacement in ((html, original_h,changed_h),(python,original_p,changed_p)):
        if replacement != original:
            path.with_name(path.name+'.bak').write_text(original,encoding='utf-8')
            path.write_text(replacement,encoding='utf-8')
            print('Patched',path)
        else:
            print('Already patched',path)
    print('Restart FastAPI and hard-refresh the browser to load the new timeline.')

if __name__=='__main__':main()
